# yolos_model.py
from transformers import YolosImageProcessor, YolosForObjectDetection
import torch
from PIL import Image
import cv2

# Load model + processor (once)
processor = YolosImageProcessor.from_pretrained("hustvl/yolos-small")
model = YolosForObjectDetection.from_pretrained("hustvl/yolos-small")

def detect_objects(image_np, confidence_threshold=0.5):
    image = Image.fromarray(cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB))
    inputs = processor(images=image, return_tensors="pt")
    outputs = model(**inputs)

    logits = outputs.logits[0]
    bboxes = outputs.pred_boxes[0]

    target_sizes = torch.tensor([image.size[::-1]])
    results = processor.post_process_object_detection(outputs, threshold=confidence_threshold, target_sizes=target_sizes)[0]

    detections = []
    for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
        detections.append({
            "label": model.config.id2label[label.item()],
            "score": round(score.item(), 2),
            "box": [int(x) for x in box.tolist()]
        })
    return detections
