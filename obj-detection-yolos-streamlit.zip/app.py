import streamlit as st
from transformers import YolosImageProcessor, YolosForObjectDetection
import torch
from PIL import Image, ImageDraw
import requests

# Load model and processor
processor = YolosImageProcessor.from_pretrained("hustvl/yolos-small")
model = YolosForObjectDetection.from_pretrained("hustvl/yolos-small")

st.title("🔍 YOLOS Object Detection with hustvl/yolos-small")
st.write("Upload an image and detect objects using a lightweight transformer model!")

uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

if uploaded_file:
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Prepare image for model
    inputs = processor(images=image, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)

    # Get detection results
    target_sizes = torch.tensor([image.size[::-1]])
    results = processor.post_process_object_detection(outputs, target_sizes=target_sizes, threshold=0.5)[0]

    # Draw boxes
    draw = ImageDraw.Draw(image)
    for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
        box = [round(i, 2) for i in box.tolist()]
        draw.rectangle(box, outline="red", width=2)
        draw.text((box[0], box[1]), f"{model.config.id2label[label.item()]} {round(score.item(), 2)}", fill="red")

    st.image(image, caption="Detected Objects", use_column_width=True)

    if len(results["labels"]) == 0:
        st.warning("No objects confidently detected!")
    else:
        st.success("Detected Objects:")
        for score, label in zip(results["scores"], results["labels"]):
            st.write(f"🟢 `{model.config.id2label[label.item()]}` — Confidence: `{round(score.item(), 2)}`")
