# utils.py
import cv2

def draw_boxes(image_np, detections):
    for det in detections:
        label = det["label"]
        score = det["score"]
        box = det["box"]

        x1, y1, x2, y2 = box
        cv2.rectangle(image_np, (x1, y1), (x2, y2), (0, 255, 0), 2)
        text = f'{label} {score:.2f}'
        cv2.putText(image_np, text, (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
    return image_np
