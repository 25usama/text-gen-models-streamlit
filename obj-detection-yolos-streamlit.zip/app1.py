# # app.py
# import streamlit as st
# import cv2
# import numpy as np
# from yolos_model import detect_objects
# from utils import draw_boxes

# st.set_page_config(page_title="YOLOS Real-Time Detection", layout="wide")
# st.title("📸 YOLOS Object Detection - Real-Time Streamlit App")

# conf_threshold = st.sidebar.slider("Confidence Threshold", 0.1, 1.0, 0.5, 0.05)

# FRAME_WINDOW = st.image([])

# run = st.checkbox('Start Webcam')
# camera = cv2.VideoCapture(0)

# if run:
#     while True:
#         ret, frame = camera.read()
#         if not ret:
#             st.warning("Failed to read from webcam.")
#             break

#         detections = detect_objects(frame, conf_threshold)
#         frame = draw_boxes(frame, detections)
#         FRAME_WINDOW.image(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
# else:
#     camera.release()
#     st.info("Webcam stopped.")



import streamlit as st
import torch
from transformers import YolosImageProcessor, YolosForObjectDetection
from PIL import Image
import cv2
import numpy as np
import time

# Title
st.title("📸 YOLOS Object Detection - Real-Time Streamlit App")

# Load Model & Processor
@st.cache_resource
def load_model():
    processor = YolosImageProcessor.from_pretrained("hustvl/yolos-small")
    model = YolosForObjectDetection.from_pretrained("hustvl/yolos-small")
    return processor, model

processor, model = load_model()

# OpenCV Webcam Capture
cap = cv2.VideoCapture(1)


if not cap.isOpened():
    st.error("❌ Failed to read from webcam.")
else:
    st.success("✅ Webcam is active.")

# Streamlit placeholder for video
frame_placeholder = st.empty()

# Real-Time Detection Loop
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        st.warning("🔁 Couldn't fetch frame.")
        break

    # Convert BGR to RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(rgb_frame)

    # Inference
    inputs = processor(images=pil_image, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)

    # Postprocess
    target_sizes = torch.tensor([pil_image.size[::-1]])
    results = processor.post_process_object_detection(outputs, threshold=0.9, target_sizes=target_sizes)[0]

    # Draw results
    for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
        box = [round(i, 2) for i in box.tolist()]
        cv2.rectangle(frame, (int(box[0]), int(box[1])), (int(box[2]), int(box[3])), (0, 255, 0), 2)
        text = f"{model.config.id2label[label.item()]}: {round(score.item(), 2)}"
        cv2.putText(frame, text, (int(box[0]), int(box[1]-10)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

    # Display updated frame
    frame_placeholder.image(frame, channels="BGR")

    # Break if Streamlit app is stopped
    if st.button("❌ Stop Webcam"):
        break

cap.release()
