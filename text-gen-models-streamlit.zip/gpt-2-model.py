import streamlit as st
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch

# Page title
st.set_page_config(page_title="AI Text Generator", layout="centered")

st.title("🚀 GPT-2 Text Generator")
st.markdown("Enter a prompt and generate human-like text using OpenAI's GPT-2 model.")

# Load model and tokenizer (cached to prevent reload)
@st.cache_resource
def load_model():
    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    model = GPT2LMHeadModel.from_pretrained("gpt2")
    return tokenizer, model

tokenizer, model = load_model()

# Input from user
prompt = st.text_area("✍️ Enter your prompt", "Once upon a time, in a distant galaxy,")

# Generation settings
max_len = st.slider("Max length", 20, 300, 100)
temperature = st.slider("Temperature (creativity)", 0.5, 1.5, 0.8)

# Generate button
if st.button("Generate"):
    with st.spinner("Generating text..."):
        input_ids = tokenizer.encode(prompt, return_tensors='pt')
        output = model.generate(
            input_ids,
            max_length=max_len,
            do_sample=True,
            temperature=temperature,
            top_k=50,
            top_p=0.95,
            no_repeat_ngram_size=2
        )
        result = tokenizer.decode(output[0], skip_special_tokens=True)
        st.success("✅ Generation complete!")
        st.markdown("### 📜 Generated Text")
        st.write(result)
