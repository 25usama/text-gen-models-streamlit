import streamlit as st
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

# Set page title and layout
st.set_page_config(page_title="Phi-2 Text Generator", layout="centered")
st.title("🧠 Phi-2 AI Text Generator")
st.markdown("Generate intelligent, human-like text using Microsoft's Phi-2 model.")

# Load model and tokenizer (cached to avoid reloading on every run)
@st.cache_resource
def load_model():
    model_name = "microsoft/phi-2"
    # hustvl/yolos-small
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name)
    return tokenizer, model

tokenizer, model = load_model()

# Input prompt
prompt = st.text_area("✍️ Enter your prompt", "Explain the difference between AI and Machine Learning.")

# Generation settings
max_len = st.slider("Max length", 20, 300, 100)
temperature = st.slider("Temperature (creativity)", 0.5, 1.5, 1.0)

# Generate button
if st.button("Generate"):
    with st.spinner("Generating..."):
        inputs = tokenizer(prompt, return_tensors="pt")
        outputs = model.generate(
            **inputs,
            max_length=max_len,
            do_sample=True,
            temperature=temperature,
            top_k=50,
            top_p=0.95,
            no_repeat_ngram_size=2
        )
        result = tokenizer.decode(outputs[0], skip_special_tokens=True)
        st.success("✅ Text generated!")
        st.markdown("### 📜 Output")
        st.write(result)
